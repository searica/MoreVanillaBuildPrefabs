### Version 0.0.3
- World-generated pieces now only their default resource drops while player-built pieces only drop the resources used to build them.
- Readme updated.
- Configuration file naming scheme changed due to automation. **You need to regeneration your configuration file and copy over any customizations you made.** Sorry for the inconvenience, future updates will not touch the configuration file naming scheme again.

### Version 0.0.2
Updated readme and added links to source code.

### Version 0.0.1
Initial release
